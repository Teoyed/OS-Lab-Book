CHAPTER 4 — TEXT FILES LAB DATA
================================

This folder contains synthetic (fictional) service-log and help-desk data for the
Operating Systems Laboratory text-processing practice. No real users or systems
are represented.

FILES
-----
service.log      Pipe-delimited service events: date|time|level|service|message
tickets.csv      Comma-separated help-desk tickets; the first row is a header.
raw_notes.txt    Deliberately inconsistent notes for a text-cleaning task.
words.txt        Words with repeated entries and mixed capitalization.

IMPORTANT
---------
1. Keep the original files unchanged. Create your results in separate output files.
2. Do not open these files in a spreadsheet program and resave them; the exercises
   are intended to be completed with Linux command-line tools.
3. These are plain-text practice files. They require no network connection after download.
